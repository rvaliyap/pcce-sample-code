// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum SsoOperationState {
  NOT_STARTED,
  BLOCKED,
  PROCESSING,
  SUCCEEDED,
  FAILED
}
