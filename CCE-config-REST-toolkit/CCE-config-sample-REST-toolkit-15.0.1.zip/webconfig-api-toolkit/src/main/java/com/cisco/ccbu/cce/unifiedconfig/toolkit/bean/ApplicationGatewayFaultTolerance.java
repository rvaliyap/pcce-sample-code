// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum ApplicationGatewayFaultTolerance {
  NONE,
  ALTERNATE_REQUEST,
  DUPLICATE_REQUEST,
  HOT_STANDBY
}
