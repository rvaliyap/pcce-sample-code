// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum InventoryUpdateOperation {
  UPDATE,
  VALIDATE_UPGRADE_COMPLETION,
  UPGRADE_COMPLETION,
  FULL_SYNC
}
