// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@XmlRootElement(name="inventoryUpdateFile")
public class InventoryUpdateFile extends BaseApiBean {
  private InventoryUpdateCategory category;
  private String content;
  private String datacenter;
  private String name;
  private InventoryUpdateOperation operation;
  private String peripheralSetName;

  public InventoryUpdateCategory getCategory() {
     return this.category;
  }

  public void setCategory(InventoryUpdateCategory category) {
     this.category = category;
  }

  public String getContent() {
     return this.content;
  }

  public void setContent(String content) {
     this.content = content;
  }

  public String getDatacenter() {
     return this.datacenter;
  }

  public void setDatacenter(String datacenter) {
     this.datacenter = datacenter;
  }

  public String getName() {
     return this.name;
  }

  public void setName(String name) {
     this.name = name;
  }

  public InventoryUpdateOperation getOperation() {
     return this.operation;
  }

  public void setOperation(InventoryUpdateOperation operation) {
     this.operation = operation;
  }

  public String getPeripheralSetName() {
     return this.peripheralSetName;
  }

  public void setPeripheralSetName(String peripheralSetName) {
     this.peripheralSetName = peripheralSetName;
  }


}
