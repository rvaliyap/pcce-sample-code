// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum ReasonTypeEnum {
  UNKNOWN,
  NOT_READY,
  LOGOUT,
  WRAPUP,
  SYSTEM_DEFINED_NOT_READY,
  SYSTEM_DEFINED_LOGOUT
}
