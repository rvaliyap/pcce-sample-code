// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum MediaRoutingType {
  voice,
  legacyMultichannel,
  multichannel
}
