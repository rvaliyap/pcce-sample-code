// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum DayPosition {
  firstOccurrence,
  secondOccurrence,
  thirdOccurrence,
  fourthOccurrence,
  lastOccurrence,
  everyOccurrence
}
