// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum StatusType {
  success,
  partialSuccess,
  failure
}
