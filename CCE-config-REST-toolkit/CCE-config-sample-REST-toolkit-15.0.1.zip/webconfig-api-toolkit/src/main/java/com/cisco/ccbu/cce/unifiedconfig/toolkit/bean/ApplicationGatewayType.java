// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum ApplicationGatewayType {
  CUSTOM_GATEWAY,
  REMOTE_ICM,
  CONTACT_SHARE
}
