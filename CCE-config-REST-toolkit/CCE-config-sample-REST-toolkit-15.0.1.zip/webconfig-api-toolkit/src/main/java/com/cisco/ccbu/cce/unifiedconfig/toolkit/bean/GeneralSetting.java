// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@Path("generalsetting")
@XmlRootElement(name="generalSettings")
public class GeneralSetting extends BaseApiBean {
  private Boolean agentEventDetailExtended;
  private String baseUrlfromRefUrl;
  private Integer changeStamp;
  private String correlationId;
  private ReferenceBean department;
  private String idFromRefUrl;
  private LoginSession loginSession;
  private String refURL;

  public Boolean getAgentEventDetailExtended() {
     return this.agentEventDetailExtended;
  }

  public void setAgentEventDetailExtended(Boolean agentEventDetailExtended) {
     this.agentEventDetailExtended = agentEventDetailExtended;
  }

  public String getBaseUrlfromRefUrl() {
     return this.baseUrlfromRefUrl;
  }

  public void setBaseUrlfromRefUrl(String baseUrlfromRefUrl) {
     this.baseUrlfromRefUrl = baseUrlfromRefUrl;
  }

  public Integer getChangeStamp() {
     return this.changeStamp;
  }

  public void setChangeStamp(Integer changeStamp) {
     this.changeStamp = changeStamp;
  }

  public String getCorrelationId() {
     return this.correlationId;
  }

  public void setCorrelationId(String correlationId) {
     this.correlationId = correlationId;
  }

  public ReferenceBean getDepartment() {
     return this.department;
  }

  public void setDepartment(ReferenceBean department) {
     this.department = department;
  }

  public String getIdFromRefUrl() {
     return this.idFromRefUrl;
  }

  public void setIdFromRefUrl(String idFromRefUrl) {
     this.idFromRefUrl = idFromRefUrl;
  }

  public LoginSession getLoginSession() {
     return this.loginSession;
  }

  public void setLoginSession(LoginSession loginSession) {
     this.loginSession = loginSession;
  }

  public String getRefURL() {
     return this.refURL;
  }

  public void setRefURL(String refURL) {
     this.refURL = refURL;
  }


  @Path("generalsetting")
  @XmlRootElement(name = "results")
  public static class GeneralSettingList extends BaseApiListBean<GeneralSetting> {
    @XmlElementWrapper(name = "generalSettingss")
    @XmlElement(name = "generalSettings")
    public List<GeneralSetting> getItems() {
      return items;
    }

    public void setItems(List<GeneralSetting> items) {
      this.items = items;
    }
  }
}
