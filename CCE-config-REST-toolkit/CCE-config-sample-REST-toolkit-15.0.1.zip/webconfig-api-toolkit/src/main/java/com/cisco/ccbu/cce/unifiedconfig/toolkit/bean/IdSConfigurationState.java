// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum IdSConfigurationState {
  STATE_NOT_CONFIGURED,
  STATE_IN_SERVICE,
  STATE_OUT_OF_SERVICE,
  STATE_PARTIAL_SERVICE,
  STATE_UNREACHABLE
}
